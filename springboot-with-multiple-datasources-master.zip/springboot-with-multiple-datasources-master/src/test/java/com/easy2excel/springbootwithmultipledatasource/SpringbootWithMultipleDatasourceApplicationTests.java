package com.easy2excel.springbootwithmultipledatasource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWithMultipleDatasourceApplicationTests {

	@Test
	void contextLoads() {
	}

}
