package com.app.FileUploadToS3Bucket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadToS3BucketApplicationTests {

	@Test
	void contextLoads() {
	}

}
