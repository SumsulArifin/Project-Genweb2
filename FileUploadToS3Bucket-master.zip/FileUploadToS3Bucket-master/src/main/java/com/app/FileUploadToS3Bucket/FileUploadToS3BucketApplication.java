package com.app.FileUploadToS3Bucket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadToS3BucketApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadToS3BucketApplication.class, args);
	}

}
