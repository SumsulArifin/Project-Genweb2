package com.app.excelcsvreadwriteapp.service;

import java.io.IOException;

public interface CsvService {
	
	
	public void readDataFromCsv(String path) throws IOException;

}
