package com.app.springbootpaymentintegration;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootPaymentIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
