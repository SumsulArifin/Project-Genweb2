package com.app.springbootpaymentintegration.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="user_details")
public class UserDetails {
	

	@Id
	@GenericGenerator(name = "user_id", strategy = "com.app.springbootpaymentintegration.generator.UserDetailsGenerator")
	@GeneratedValue(generator = "user_id")
	
	
	
	@Column(name="user_id")
	private String user_id;
	
	@Column(name="first_name")
	private String first_name;
	
	@Column(name="last_name")
	private String last_name;
	
	@Column(name="email")
	private String email;
	
	@Column(name="password")
	private String password;
	
	@Column(name="role")
	private String role;
	
	@Column(name="confirm_password")
	private String confirm_password;
	
	@Column(name="creation_date")
	private Date creation_date;

	@Column(name="stripe_customer_id")
	private String stripe_customer_id;

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirm_password() {
		return confirm_password;
	}

	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}

	public Date getCreation_date() {
		return creation_date;
	}

	public void setCreation_date(Date creation_date) {
		this.creation_date = creation_date;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStripe_customer_id() {
		return stripe_customer_id;
	}

	public void setStripe_customer_id(String stripe_customer_id) {
		this.stripe_customer_id = stripe_customer_id;
	}
	
	
	
	
}