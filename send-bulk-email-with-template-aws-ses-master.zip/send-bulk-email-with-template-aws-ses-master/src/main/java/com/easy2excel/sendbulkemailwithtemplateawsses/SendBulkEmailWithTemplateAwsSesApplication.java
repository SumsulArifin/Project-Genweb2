package com.easy2excel.sendbulkemailwithtemplateawsses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SendBulkEmailWithTemplateAwsSesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SendBulkEmailWithTemplateAwsSesApplication.class, args);
		System.out.println("application running fine........");
	}

}
