package com.easy2excel.springboottransactionmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootTransactionManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
