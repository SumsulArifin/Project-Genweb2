package com.thomasjayconsulting.multidb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
