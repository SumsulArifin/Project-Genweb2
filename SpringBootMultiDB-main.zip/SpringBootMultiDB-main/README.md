# SpringBootMultiDB
Multiple Databases with Spring Boot MySQL and MongoDB
