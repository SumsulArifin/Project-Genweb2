package com.app.easy2excel.s3fileuploadusingpresignedurl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3FileUploadUsingPresignedUrlApplicationTests {

	@Test
	void contextLoads() {
	}

}
